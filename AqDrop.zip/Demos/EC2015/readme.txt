This demo was used to show DROP at Embarcadero Conference Brazil 2015.

The demo was written in portuguese (ASAP we will translate it to English too).

The database to this demo is the SQLite.