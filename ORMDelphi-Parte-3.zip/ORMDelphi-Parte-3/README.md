# ORMDelphi
Como fazer seu próprio ORM utilizando Delphi o tutorial pode ser visto no canal Just Code no youtube.
# Parte 1
[![Parte1](http://img.youtube.com/vi/jC5NvkW6Ch8/0.jpg)](http://www.youtube.com/watch?v=jC5NvkW6Ch8)

Pode ser acessado o fonte na branche Parte-1

# Parte 2
[![Parte1](http://img.youtube.com/vi/UctxcGL_uAA/0.jpg)](http://www.youtube.com/watch?v=UctxcGL_uAA)

Pode ser acessado o fonte na branche Parte-2

